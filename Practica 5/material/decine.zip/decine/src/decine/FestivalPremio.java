/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package decine;

/**
 *
 * @author ana
 */
class FestivalPremio {
    private String nombre;
    
    FestivalPremio(String nombre){
        this.nombre = nombre;
    }
}
