/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package decine;

/**
 *
 * @author ana
 */
 class Actor {
    private String nombre;
    private String nacionalidad;
    private String webOficial;
    
    Actor(String nombre, String nacionalidad, String web){
        this.nombre =nombre;
        this.nacionalidad = nacionalidad;
        this.webOficial = web;
    }
    
}
